/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum1.quis1_s1si05a_3002;

/**
 *
 * @author ASUS
 * ELSAMAULIDA_21103002
 */
public class Penduduk_3002 {
    protected String nik_3002;
    protected String nama_3002;
    protected int umur_3002;
    protected String alamat_3002;
    
    public void tampilDataPenduduk(){
        System.out.println("NIK : "+nik_3002);
        System.out.println("Nama : "+nama_3002);
        System.out.println("Umur : "+umur_3002);
        System.out.println("Alamat : "+alamat_3002);   
    }
}
