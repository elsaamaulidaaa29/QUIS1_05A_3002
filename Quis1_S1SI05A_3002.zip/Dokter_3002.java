/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum1.quis1_s1si05a_3002;

/**
 *
 * @author ASUS
 * ELSAMAULIDA_21103002
 */
public class Dokter_3002 extends Penduduk_3002{
    int jmlPasien_3002;
    int jmlObat_3002;
    double gaji_3002;
   
    
    public double totalPendapatanDokter(){
        gaji_3002 = (jmlPasien_3002 * 50000) + (jmlObat_3002*10000);
        return gaji_3002;
    }
    
    public void tampilDataDokter(){
        tampilDataPenduduk();
        System.out.println("Jumlah Pasien : "+jmlPasien_3002);
        System.out.println("Jumlah Obat : "+jmlObat_3002);
        System.out.println("Gaji : "+gaji_3002);
        
    }
}
