/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package praktikum1.quis1_s1si05a_3002;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author ASUS
 * ELSAMAULIDA_21103002
 */
public class Quis1_S1SI05A_3002 extends Penduduk_3002{

    public static void main(String[] args){
        Nelayan_3002 A = new Nelayan_3002();
        Nelayan_3002 B = new Nelayan_3002();
        Dokter_3002 C = new Dokter_3002();
        Dokter_3002 D = new Dokter_3002();
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.println("NIK     : ");
            A.nik_3002 = br.readLine();
            System.out.println("Nama    : ");
            A.nama_3002 = br.readLine();
            System.out.println("Umur    : ");
            A.umur_3002 = Integer.parseInt(br.readLine());
            System.out.println("Alamat  : ");
            A.alamat_3002 = br.readLine();
            System.out.println("Jumlah Berat Ikan : ");
            A.jmlBeratIkan_3002 = Integer.parseInt(br.readLine());
            System.out.println("Jumlah Solar : ");
            A.jmlSolar_3002 = Integer.parseInt(br.readLine());
            System.out.println();
            System.out.println("Gaji Pokok : ");
            A.gaji_3002 = Integer.parseInt(br.readLine());
            System.out.println("");
            
            
            System.out.println("NIK     : ");
            B.nik_3002 = br.readLine();
            System.out.println("Nama    : ");
            B.nama_3002 = br.readLine();
            System.out.println("Umur    : ");
            B.umur_3002 = Integer.parseInt(br.readLine());
            System.out.println("Alamat  : ");
            B.alamat_3002 = br.readLine();
            System.out.println("Jumlah Berat Ikan : ");
            B.jmlBeratIkan_3002 = Integer.parseInt(br.readLine());
            System.out.println("Jumlah Solar : ");
            B.jmlSolar_3002 = Integer.parseInt(br.readLine());
            System.out.println();
            System.out.println("Gaji Pokok : ");
            B.gaji_3002 = Integer.parseInt(br.readLine());
            System.out.println("");
            
           
            
            System.out.println("NIK             : ");
            C.nik_3002 = br.readLine();
            System.out.println("Nama            : ");
            C.nama_3002 = br.readLine();
            System.out.println("Umur            : ");
            C.umur_3002 = Integer.parseInt(br.readLine());
            System.out.println("Alamat          : ");
            C.alamat_3002 = br.readLine();
            System.out.println("Jumlah Pasien   : ");
            C.jmlPasien_3002 = Integer.parseInt(br.readLine());
            System.out.println("Jumlah Obat     : ");
            C.jmlObat_3002 = Integer.parseInt(br.readLine());
            System.out.println("Gaji Pokok      : ");
            C.gaji_3002 = Integer.parseInt(br.readLine());
            System.out.println("");
            
            System.out.println("NIK             : ");
            D.nik_3002 = br.readLine();
            System.out.println("Nama            : ");
            D.nama_3002 = br.readLine();
            System.out.println("Umur            : ");
            D.umur_3002 = Integer.parseInt(br.readLine());
            System.out.println("Alamat          : ");
            D.alamat_3002 = br.readLine();
            System.out.println("Jumlah Pasien   : ");
            D.jmlPasien_3002 = Integer.parseInt(br.readLine());
            System.out.println("Jumlah Obat     : ");
            D.jmlObat_3002 = Integer.parseInt(br.readLine());
            System.out.println("Gaji Pokok      : ");
            D.gaji_3002 = Integer.parseInt(br.readLine());
            System.out.println("");
            
            
            System.out.println("==== DATA NELAYAN ====");
            A.tampilDataNelayan();
            System.out.println("Total Pendapatan    : Rp "+A.totalPendapatanNelayan());
            System.out.println("");
            B.tampilDataNelayan();
            System.out.println("Total Pendapatan    : Rp "+B.totalPendapatanNelayan());
            System.out.println("====== DATA DOKTER ======");
            C.tampilDataDokter();
            System.out.println("Total Pendapatan    : Rp "+C.totalPendapatanDokter());
            System.out.println("");
            D.tampilDataDokter();
            System.out.println("Total Pendapatan    : Rp "+D.totalPendapatanDokter());
        }
        catch(Exception ex){
            System.out.println(ex);
        }
    }
    }
