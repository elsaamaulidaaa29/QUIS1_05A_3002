/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum1.quis1_s1si05a_3002;

/**
 *
 * @author ASUS
 * ELSAMAULIDA_21103002
 */
public class Nelayan_3002 extends Penduduk_3002{
    int jmlBeratIkan_3002;
    int jmlSolar_3002;
    double gaji_3002;
    
    public double totalPendapatanNelayan(){
        gaji_3002 = (jmlBeratIkan_3002 * 8000) - (jmlSolar_3002 * 10000);
        return gaji_3002;
    }
    
    public void tampilDataNelayan(){
        tampilDataPenduduk();
        System.out.println("Jumlah Berat Ikan : "+jmlBeratIkan_3002);
        System.out.println("Jumlah Solar : "+jmlSolar_3002);
        System.out.println("Gaji : "+gaji_3002);
    }
}
